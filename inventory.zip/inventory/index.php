
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>

    <style>
    *,*::before,*::after{box-sizing:border-box}body,h1,h2,h3,h4,p,figure,blockquote,dl,dd{margin:0}ul[role="list"],ol[role="list"]{list-style:none}html:focus-within{scroll-behavior:smooth}body{min-height:100vh;text-rendering:optimizeSpeed;line-height:1.5}a:not([class]){text-decoration-skip-ink:auto}img,picture{max-width:100%;display:block}input,button,textarea,select{font:inherit}@media(prefers-reduced-motion:reduce){html:focus-within{scroll-behavior:auto}*,*::before,*::after{animation-duration:.01ms !important;animation-iteration-count:1 !important;transition-duration:.01ms !important;scroll-behavior:auto !important}}


        body#loginbody{
	        background: url('images/main.png')no-repeat center center fixed;
	        background-size: cover;
        }
        body{
            font-family: 'Times New Roman', Times, serif;
        }
        .header {
            text-align: center; /* Center text */
            padding: 20px 0; /* Add some padding */
            color: #fff; /* Set text color */
			font-size: 25px;
        }
        .container {
            color: lightgreen;
            background: rgba(0, 0, 0, 0.6); /* Slightly darker for better contrast */
            padding: 75px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
            justify-content: auto;
            color: lightgreen;
            flex-direction: column; /* Changed to column to stack elements */
            align-items: center; /* Center align items */
        }
		h1{
            padding: 25px;
			color: green;
			line-height: 75%;
			max-width: 900px;
			margin: 0 auto;
		}
        h2{
			color: green;
			line-height: 100%;
			max-width: 900px;
			margin: 0 auto;
            }
        h4{
            color: green;
        }
        .login{
            /* Added margin for spacing */
            color:black; /* Set color for link */
            text-decoration: none; /* Remove underline */
        }
        .login:hover{
            text-decoration: underline; 
        }
        .oover{
            text-align: center;
        }
        .team:hover{
            text-decoration: underline;
            color: lightgreen;
        }
        .team{
            color: lightgreen;
            text-decoration: none;
        }
    </style>
</head>
<body id="loginbody">
        <div class="header">
            <h1>WELCOME TO</h1>
            <h2>MEDICATION ADHERENCE TRACKING</h2>
            <h4>INVENTORY</h4>
        </div>
    
    <div class="container">
        <form action="homepage.php" method="post" autocomplete="off">
        <h3>OVERVIEW OF THE SYSTEM  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <a href="#" class="team">TEAM SECTION</a></h3>
        <p> A web-based platform specifically designed to address the needs of our Client. 
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        
        <a href="#" class="team">RECOMMENDATION</a><br>
        This system enables efficient tracking of medications that are low in stock, <br>
        ensuring that the clinic is always adequately stocked to meet the needs <br>
        of students requiring medication. </p>
        </form>
    </div>
    <br>
    <div class="oover">
    <a href="login.php" class="login">Already have an account? Click here</a></br>
	</div>
</body>
</html>