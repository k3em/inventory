<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
<link rel="stylesheet" type="text/css" href="css/customStyle.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<script src='js/jquery.js'></script>
<script src='js/bootstrap.min.js'></script>

	<style type="text/css">
	
.fontvari{ font-variant: small-caps; }
.center{ text-align: center; }
.left{ text-align:left; }
.right{text-align: right;}
.full{height: 100%}
.white{ color:white; }
.black{color:white;}
.mini-btn{padding: 1px 12px;margin:1px;}
.flex{display: flex; display: -webkit-flex;}
.mini-details{font-size: 9pt; font-size: bold}
.panel{width: 100%;border-radius: 3px;border:1px solid #D2D3D6;}
.panel-head{background: #E5F1FB ;border-bottom: 1px solid #D2D3D6;padding: 11px;border-radius: 3px 3px 0 0;font-size: 14pt;font-weight: bold}
.panel-body{background: white;padding: 14px 11px;border-radius:0 0 3px 3px}
.hidden{display: none;}
.thumb{ border: 1px solid #B2B2B2; padding: 3px;background: white}.red{color:red;}
.blue{color:orange;}
.green{color:green;}
.inline li{display: inline}
.flex{display: flex}
.zero{padding: 0;margin:0;}
.nostyle{list-style-type: none}
body{margin: 0;background:#ECF3F6 ;}
.fright{ float: right; }
.fleft{ float: left; }
.clear{clear: both}
.sans{ font-family: sans-serif; }
.strong{font-weight: bold}
.half{width: 50%}
.fontTreb{font-family: trebuchet ms}
.marginauto{margin:auto;}
.bg{background: orange}
.m1{margin: 1px}
.mauto{margin: auto;}
.bg-green{background: green;color: white}
/*---- index.php----*/


.topHead{font-size: 22pt;background:#145632;padding: 24px;color:gold;text-shadow: 2px 2px black}
		
.cover{padding: 11px;}
.cvBody{border:1px solid black; width: 57%;min-height: 444px;}
.cv-head{background:#212121;width: 40%;padding: 4px}
.photo{background:#283136;height: 222px}
.cv-content{width: 60%}
.center{text-align: center;}
.flex{display: inline-flex;}

.marginLeft{margin-left: 18%;}
.item ul li{color: #72A4A4;background:#2C3B41;padding: 4px;padding-left: 22px;}
.item ul li:hover{color:white;}
.rightAccount:hover{background:green;cursor: pointer;}
.account{width: 277px;background:#F9F9F9;;position: absolute;right:2px;margin-top: 2px;}
.content2{padding:15px 22px;}
.box2{padding: 7px;background:white;margin: 14px;width: 222px;border-top: 3px solid green;z-index: -1;box-shadow: 1px 1px 3px silver;cursor: pointer;}
.box2:hover{box-shadow: 1px 1px 11px black}

.tableBox{background:white;box-shadow: 1px 1px 11px silver;margin:5px;padding: 11px;}
	
	</style>
</head>
<body style="background: url('images/login1.jpg')no-repeat center center fixed;background-size: cover">
	<div class="login-box">
   <div class=" center">
    <img src="images/logo.png" style="width:25%; height: 36vh;margin-top: 45px;">
  </div>
  <!-- /.login-logo -->
  <div class="well well-sm" style="width: 25%;margin:auto;padding: 22px;margin-top: 22px;z-index: 6">
    <p class="login-box-msg">Sign in to start your session</p>
    <form action="" method="post">
      <div class="form-group has-feedback">
        <input type="email" name="email" class="form-control" placeholder="Email" required>
        
      </div>
      <div class="form-group has-feedback">
        <input type="password" name="password" class="form-control" placeholder="Password" required>
        
      </div>
    
      <button type="submit" name="login" class="btn btn-primary btn-block btn-flat">Sign In</button>
    </form>
  </div>
  <br>
  <div class="alert alert-danger" id="error"  style="width: 25%;margin: auto;display: none;"></div>
  <div style="position: fixed;;top:0;background: rgba(0,0,0,0.7); width: 100%;height: 100%;z-index: -1"></div>

  <!-- /.login-box-body -->
</div>
<!-- Modal -->
<div id="successModal" class="modal" style="display:none;">
    <div class="modal-content">
        <span class="close" onclick="document.getElementById('successModal').style.display='none'">&times;</span>
        <p>You are successfully entered the homepage</p>
    </div>
</div>
</body>
</html>

<?php 
include './classes/database.php';
include_once './classes/user.php';
?>
<?php
// Create an instance of the User class
$user = new User($db); // Assuming $db is your database connection object

if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Call the login method on the User instance
    $db = $user->login($email, $password);
    if ($db) {
        // Show modal and redirect to homepage
        echo "<script>
                document.getElementById('successModal').style.display='block';
                setTimeout(function() {
                    window.location.href = 'http://localhost/inventory/homepage.php';
                }, 2000); // Redirect after 2 seconds
              </script>";
        exit();
    } else {
        echo "<script>
                $(document).ready(function() {
                    $('#error').slideDown().html('Login Error! Try again.').delay(3000).fadeOut();
                });
              </script>";
    }
}
?>