DEVELOP MEDICATION ADHERENCE TRACKING DASHBOARD USING PHP OOP STRUCTURE AND MYSQL WITHOUT USING SESSION AND PDO



-- Create the database
CREATE DATABASE inventory;

-- Use the database
USE inventory;

-- Create the users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    
);


CREATE TABLE  medicines (
            id INT(11) AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            quantity INT(11) NOT NULL,
            status ENUM('Available', 'Low of Stock') NOT NULL
image VARCHAR(255) NOT NULL
        )


CREATE TABLE patient (
            id INT(11) AUTO_INCREMENT PRIMARY KEY,
            program VARCHAR(255) NOT NULL,
            year VARCHAR(11) NOT NULL,
            firstname VARCHAR(255) NOT NULL,
            lastname VARCHAR(255) NOT NULL,
            name TEXT,
            symptoms TEXT
        )





CREATE TABLE medications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    dosage VARCHAR(50) NOT NULL,
    frequency VARCHAR(50) NOT NULL,
    last_taken DATETIME,
    adherence_status ENUM('Adhered', 'Missed') NOT NULL
);