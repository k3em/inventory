<?php
// Include the database and user class files
include_once 'classes/database.php'; // Ensure this path is correct
include_once 'classes/user.php'; // Ensure this path is correct
?>
<?php
// Create a new user object
$user = new User($db); // Instantiate the User class here

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Register the user
    if ($user->register($email, $password)) {
        echo "User  registered successfully!";
    } else {
        echo "User  registration failed!";
    }
}
?>

<!-- HTML Form for User Registration -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width , initial-scale=1.0">
    <title>User Registration</title>
</head>
<body>
    <form method="POST" action="">
        <label for="email">Email:</label>
        <input type="email" name="email" required>
        <br>
        <label for="password">Password:</label>
        <input type="password" name="password" required>
        <br>
        <input type="submit" value="Register">
    </form>
</body>
</html>