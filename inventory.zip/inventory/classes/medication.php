<?php
class Medication extends Database {
    private $conn;
    private $table_name = "medications";

    public function __construct($db) {
        $this->conn = $db;
    }

    public function addMedication($name, $dosage, $frequency) {
        $stmt = $this->conn->prepare("INSERT INTO " . $this->table_name . " (name, dosage, frequency, adherence_status) VALUES (?, ?, ?, 'Adhered')");
        $stmt->bind_param("sss", $name, $dosage, $frequency);
        return $stmt->execute();
    }

    public function getMedications() {
        $result = $this->conn->query("SELECT * FROM " . $this->table_name);
        return $result->fetch_all(MYSQLI_ASSOC);
    }

    public function updateAdherence($id, $status) {
        $stmt = $this->conn->prepare("UPDATE " . $this->table_name . " SET adherence_status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $id);
        return $stmt->execute();
    }
}
?>