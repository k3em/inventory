<?php
class Database {
    private $servername;
    private $username;
    private $password;
    private $dbname;

    protected function connect() {
        $this->servername = "localhost";
        $this->username = "root";
        $this->password = "";
        $this->dbname = "inventory";

        $conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);
        return $conn;
    }
}

class DatabaseConnection extends Database {
    public function getConnection() {
        return $this->connect(); // Accessing the protected method
    }
}

// Create a new database connection
$database = new DatabaseConnection();
$db = $database->getConnection(); // This will work



?>

