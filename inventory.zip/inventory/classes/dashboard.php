<?php
class Medicines extends Database {
    public $medicines = [];
    private $conn;

    public function __construct($servername, $username, $password, $dbname) {
        // Create a new database connection
        $this->conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }

    public function insertMedicine($name, $quantity, $status, $image) {
        $this->medicines[] = [
            'name' => $name,
            'quantity' => $quantity,
            'status' => $status,
            'image' => $image
        ];
    }

    public function getMedicines() {
        $medicines = [];
        // Fetch medicines from the database
        $sql = "SELECT * FROM medicines"; // SQL query to fetch all medicines
        $result = $this->conn->query($sql);
    
        // Initialize the medicines array
        $this->medicines = []; // Reset the array to avoid duplicates
    
        if ($result && $result->num_rows > 0) {
            // Fetch all medicines into the array
            while($row = $result->fetch_assoc()) {
                $this->medicines[] = $row;
            }
        }
    
        return $this->medicines; // Return the medicines array
    }
}
?>