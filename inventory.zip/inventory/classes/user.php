<?php
class User extends Database {
    private $conn;

    public function __construct($db) {
        $this->conn = $db; 
    }

   
    public function register($email, $password) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $query = "SELECT * FROM `users` WHERE email = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("s", $email);

        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            return false; 
        }

        $query = "INSERT INTO `users` (email, password) VALUES (?, ?)";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ss", $email, $hashed_password); 
    
        if ($stmt->execute()) {
            return true; 
        }

        return false; 
    }

    // Method to login a user
    public function login($email, $password) {
        // Prepare the SQL statement to check if the email exists
        $query = "SELECT * FROM `users` WHERE email = ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("s", $email); // Bind the email parameter

        // Execute the query
        $stmt->execute();
        $result = $stmt->get_result();

        // Check if the email exists
        if ($result->num_rows === 0) {
            return false; // Email does not exist
        }

        // Fetch the user data
        $user = $result->fetch_assoc();

        // Verify the password
        if (password_verify($password, $user['password'])) {
            return true; // Login successful
        }

        return false; // Incorrect password
    }
}


?>