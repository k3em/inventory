
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Homepage</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Material+Icons" />	
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
	<script src="https://use.fontawesome.com/0c7a3095b5.js"></script>
</head>
<body>
	<style>
		.featureTitle{
			color: black;
			text-decoration: none;

		}
		.featureTitle:hover{
			text-decoration: underline;
			color:darkgreen;
		}
		
	</style>
	<form action="">
	<div class="header">
		<div class="homepageContainer">
			<a href="index.php">Logout</a>
		</div>
		
	</div>
	<div class="banner">
		<div class="homepageContainer">
			<div class="bannerHeader">
				<h1>MEDICATION ADHERENCE TRACKING</h1>
			</div>
			<p class="bannerTagline">
			Track your medicines throughout your entire supply chain
			</p>
			<div class="bannerIcons">
			<a href=""><i class="fa fa-apple"></i></a>
			<a href=""><i class="fa fa-android"></i></a>
			<a href=""><i class="fa fa-windows"></i></a>
			</div>
			</div>
		</div>			
		<div class="homepageContainer">
		<div class="homepageFeatures">
			<div class="homepageFeature">
				<span class="featureIcon"><i class="fa fa-dashboard"></i></span>
				<h3><a href="dashboard.php" class="featureTitle">DASHBOARD</a></h3>
				<p class="featureDescription">serves as a tool for consolidating information, 	into a single interface.</p>
				<div class="bannerIcons"></div>
			</div>
			<div class="homepageFeature">
				<span class="featureIcon"><i class="fa fa-user"></i></span>
				<h3><a href="admin.php" class="featureTitle">ADMIN</a></h3>
				<p class="featureDescription">where your medicine's located, welcome aboard!</p>
			</div>
			<div class="homepageFeature">
				<span class="featureIcon"><i class="fa-solid fa-notes-medical"></i></span>
				<h3><a href="#" class="featureTitle">MEDICINES</a></h3>

				<p class="featureDescription">enhance the processes related to medication, by automating tasks.</p>
			</div>
			
	</div>
</form>
</body>
</html>