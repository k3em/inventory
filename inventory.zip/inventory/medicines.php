<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>   
    <link rel="stylesheet" href="css/css.css"></link>
    
    <title>Admin Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        a:hover{
            
            border: 1px solid ;
            border-color:#f4f4f4;
            border-radius:2px ;
}
        nav {
            display: flex;
            align-items: center;
            background-color: #ff6600;
            padding: 10px;
        }
        nav img {
            width: 95px;
            height: 75px;
        }
        nav h4 {
            color: #fff;
            margin-left: 10px; /* Space between logo and text */
        }
        nav ul {
            list-style-type: none;
            margin-left: auto; /* Pushes the menu to the right */
            padding: 0;
        }
        nav ul li {
            display: inline;
            margin: 0 15px;
        }
        nav ul li a {
            color: #fff;
            text-decoration: none;
        }
        nav ul li a:hover {
            text-decoration: none;
            color:white;
        }
    </style>
</head>
<body>
    <nav>
        <img src="images/logo.png" alt="Admin Logo">
        <h4>Medicines</h4>
        <ul>
            <li><a href="homepage.php" title="Go to Homepage">Home</a></li>
            <li><a href="Dashboard.php" title="Go to Dashboard">Dashboard</a></li>
            <li><a href="patient.php" title="View Patient">Patient</a></li>
            <li><a href="admin.php" title="Go to Profile">Profile</a></li>
            <li><a href="#" title="Logout to your account">Logout</a></li>
        </ul>
    </nav>

    <div class="head-title">
                
                  
                <ul class="breadcrumb">
                    <li>
                        <a href="#"><p>Medicines</p></a>
                    </li>
                    <li><i class='bx bx-chevron-right' ></i></li>
                    <li>
                        <a class="active" href="#">Back</a>
                    </li>
                </ul>
            </div>
<hr style="border:1px solid; background-color:green; border-color:#3B3131;">




</body>
</html>