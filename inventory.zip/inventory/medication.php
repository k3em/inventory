<?php
require_once 'classes/Database.php';
require_once 'classes/Medication.php';

$db = new Database();
$conn = $db->getConnection();
$medication = new Medication($conn);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add'])) {
        $medication->addMedication($_POST['name'], $_POST['dosage'], $_POST['frequency']);
    } elseif (isset($_POST['update'])) {
        $medication->updateAdherence($_POST['id'], $_POST['status']);
    }
}

// Fetch medications
$medications = $medication->getMedications();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medication Tracker</title>
    <link rel="stylesheet" type="text/css" href="css/styles.css"> <!-- Link to CSS -->
</head>
<body>
    <h1>Medication Tracker</h1>

    <h2>Add Medication</h2>
    <form method="POST">
        <input type="text" name="name" placeholder="Medication Name" required>
        <input type="text" name="dosage" placeholder="Dosage" required>
        <input type="text" name="frequency" placeholder="Frequency" required>
        <button type="submit" name="add">Add Medication</button>
    </form>

    <h2>Medications</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Dosage</th>
            <th>Frequency</th>
            <th>Last Taken</th>
            <th>Adherence Status</th>
            <th>Update Status</th>
        </tr>
        <?php foreach ($medications as $med): ?>
        <tr>
            <td><?php echo $med['id']; ?></td>
            <td><?php echo $med['name']; ?></td>
            <td><?php echo $med['dosage']; ?></td>
            <td><?php echo $med['frequency']; ?></td>
            <td><?php echo $med['last_taken'] ? date('Y-m-d H:i:s', strtotime($med['last_taken'])) : 'N/A'; ?></td>
            <td><?php echo $med['adherence_status']; ?></td>
            <td>
                <form method="POST">
                    <input type="hidden" name="id" value="<?php echo $med[' id']; ?>">
                    <select name="status">
                        <option value="Adhered">Adhered</option>
                        <option value="Missed">Missed</option>
                    </select>
                    <button type="submit" name="update">Update</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>